CREATE TABLE IF NOT EXISTS games (
  id INTEGER ,
  game_id TEXT ,
  tx TEXT ,
  PRIMARY KEY(id ASC)
);

