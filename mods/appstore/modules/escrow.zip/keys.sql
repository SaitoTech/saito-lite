CREATE TABLE IF NOT EXISTS keys (
  id INTEGER ,
  user_id INTEGER ,
  publickey TEXT ,
  privatekey TEXT ,
  PRIMARY KEY(id ASC)
);

