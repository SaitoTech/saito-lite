module.exports = GetTokensAppspaceTemplate = () => {
  return `
    This module tracks the tokens you have been given / refunded by the Transaction Faucet
  `;
}
