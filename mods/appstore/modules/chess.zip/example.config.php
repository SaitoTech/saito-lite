<?php
define('APP_PATH', '/path/to/your/git/repo/');
define('BASE_URL', 'http://chessboardjs.com/');
define('IN_PRODUCTION', true);
define('PROJECT_NAME', 'chessboard.js');
?>