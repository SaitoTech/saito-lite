$(document).ready(function() {

prettyPrint();

});