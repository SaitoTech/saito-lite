module.exports = ArcadeRightSidebarTemplate = () => {
  return `
    <!-- <div class="arcade-extra"> -->

    <div class="arcade-sidebar-box">
      <h2 class="arcade-sidebar-active-games-header">Watch Live</h2>
      <div class="arcade-sidebar-active-games-body"></div>
    </div>
    <div class="arcade-sidebar-respondees"></div>

    <!-- </div> -->
  `;
}
