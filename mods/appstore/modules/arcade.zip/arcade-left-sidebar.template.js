module.exports = ArcadeLeftSidebarTemplate = () => {
  return `

  <div class="arcade-controls">
      <div class="arcade-bars-menu">
          <div class="arcade-navigator-bars-menu">
              <h2>Quick Start</h2>
              <div class="arcade-apps-wrapper">
                  <ul class="arcade-apps" id="arcade-apps">
                  </ul>
              </div>
          </div>
      </div>
  </div>
  <div class="add-games-control">
  <h3>Get More Games</h3>
      <button class="add-games"><i class="fas fa-plus-circle"></i>Saito Appstore</button>
  </div>
  <div class="email-chat"></div>
    
  `;
}
