module.exports = ArcadeLoaderTemplate = () => {
  return `
      <div class="arcade-initialize-game-container">
        <center>Your game is initializing with your opponent. Please do not leave this page</center>
        <center><div class="loader" id="game_spinner"></div></center>
        <center><div id="status" class="status"></div></center>
      </div>
  `;
}
