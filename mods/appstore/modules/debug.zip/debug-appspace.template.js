module.exports = DebugAppspaceTemplate = () => {
  return `
  <link rel="stylesheet" type="text/css" href="/saito/lib/jsonTree/jsonTree.css" /> 
  <h3>App Configuration</h3> 
  <hr />
  <div id="email-appspace-debug" class="email-appspace-debug"></div>
  <hr />
  `;
}