module.exports = EmailListTemplate = () => {
  return `
      <div class="email-list"></div>
  `;
}