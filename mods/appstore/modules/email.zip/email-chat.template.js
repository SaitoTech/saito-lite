module.exports = EmailChatTemplate = () => {
  return ``;
}
