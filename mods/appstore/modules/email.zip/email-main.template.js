module.exports = EmailMainTemplate = () => {
  return `
      <div class="email-header"></div>
      <div class="email-body"></div>
      <button id="email" class="create-button"><i class="fas fa-plus"></i></button>
  `;
}
