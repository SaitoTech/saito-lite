module.exports = EmailAppspaceTemplate = () => {
  return `
    <div class="email-appspace">
      <center><div class="loader"></div></center>
    </div>
  `;
};

