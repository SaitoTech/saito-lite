module.exports = EmailSidebarTemplate = () => {
  return `
    <div class="email-controls">
    </div>
    <div class="email-chat">
    </div>
  `;
}
