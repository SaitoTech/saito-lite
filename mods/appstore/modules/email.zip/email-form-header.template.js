module.exports = EmailHeaderTemplate = (app, data) => {
  return `
    <div class="email-icons">
      <i id="email-form-back-button" class="icon-med fas fa-arrow-left"></i>
    </div>
    <div class="email-balance"></div>
  `;
}
