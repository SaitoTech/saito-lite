module.exports = TestingAppspaceTemplate = () => {
  return `
<div class="email-appspace-testing">
  <h3>Test Button:</h3>
  <p>
    Enter a private key or address to perform an onchain Diffie-Hellman key exchange and encrypt your transactions.
  </p>
  <br />
  <div class="testdiv" id="testdiv">

  </div>
  <button class="testing-btn">Click to Test Button</button>
</div> 
  `;
}
