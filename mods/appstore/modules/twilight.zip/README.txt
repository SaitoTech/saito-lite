All of the files in this directory are owned by GMT Games and may only be used or distributed in compliance with their requirements for legal use. Please see the license directory for information on the legal use and distribution of these files.


