module.exports = AdminAppspaceTemplate = (app) => {
  return `
  <link rel="stylesheet" href="/admin/style.css">
  <div class="alaunius-appspace-admin">
      <h3>Hospital Information -- Administration</h3>
  
      <p></p>

      <table>

	<tr>
	  <th>name</th>
	  <th>publickey</th>
	  <th>address</th>
	  <th>department</th>
	  <th>role</th>
	  <th>phone</th>
	  <th>email</th>
	  <th>hours</th>
        </tr>

	<tr>
	  <td>William Smith</td>
	  <td>dxnL8fRNchesE6dnwDEPjQ19WS1rTMAh19C9VyNappXu</td>
	  <td>74 Regina Drive, Phuket, Thailand</td>
	  <td>Cardiology</td>
	  <td>Doctor</td>
	  <td>4133-3124</td>
	  <td>wsmith@saito</td>
	  <td>9:00 - 20:00</td>
	</tr>
	<tr>
	  <td>William Smith</td>
	  <td>dxnL8fRNchesE6dnwDEPjQ19WS1rTMAh19C9VyNappXu</td>
	  <td>74 Regina Drive, Phuket, Thailand</td>
	  <td>Cardiology</td>
	  <td>Doctor</td>
	  <td>4133-3124</td>
	  <td>wsmith@saito</td>
	  <td>9:00 - 20:00</td>
	</tr>
	<tr>
	  <td>William Smith</td>
	  <td>dxnL8fRNchesE6dnwDEPjQ19WS1rTMAh19C9VyNappXu</td>
	  <td>74 Regina Drive, Phuket, Thailand</td>
	  <td>Cardiology</td>
	  <td>Doctor</td>
	  <td>4133-3124</td>
	  <td>wsmith@saito</td>
	  <td>9:00 - 20:00</td>
	</tr>
	<tr>
	  <td>William Smith</td>
	  <td>dxnL8fRNchesE6dnwDEPjQ19WS1rTMAh19C9VyNappXu</td>
	  <td>74 Regina Drive, Phuket, Thailand</td>
	  <td>Cardiology</td>
	  <td>Doctor</td>
	  <td>4133-3124</td>
	  <td>wsmith@saito</td>
	  <td>9:00 - 20:00</td>
	</tr>
	<tr>
	  <td>William Smith</td>
	  <td>dxnL8fRNchesE6dnwDEPjQ19WS1rTMAh19C9VyNappXu</td>
	  <td>74 Regina Drive, Phuket, Thailand</td>
	  <td>Cardiology</td>
	  <td>Doctor</td>
	  <td>4133-3124</td>
	  <td>wsmith@saito</td>
	  <td>9:00 - 20:00</td>
	</tr>
	<tr>
	  <td>William Smith</td>
	  <td>dxnL8fRNchesE6dnwDEPjQ19WS1rTMAh19C9VyNappXu</td>
	  <td>74 Regina Drive, Phuket, Thailand</td>
	  <td>Cardiology</td>
	  <td>Doctor</td>
	  <td>4133-3124</td>
	  <td>wsmith@saito</td>
	  <td>9:00 - 20:00</td>
	</tr>

      </div>
  </div>
  `;
}
