module.exports = AppStoreSearchTemplate = () => {
  return `

      <div class="email-appspace-appstore">

	<h2>Install Saito Modules:</h2>

	<div>

	  Installing a module gives it full access to your Saito wallet:

	  <p></p>

	  <input type="text" id="appstore-search" name="appstore-search" />
	  <button class="button" id="appstore-search-btn">Search</button>

	  <p></p>

	  <div class="search-results" id="search-results">
	  </div>


      </div>
  `;
}
