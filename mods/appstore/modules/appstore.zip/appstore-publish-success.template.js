module.exports = AppStorePublishSuccessTemplate = () => {
  return `
    <h2>You've submited your module successfully!</h2>
  `;
}