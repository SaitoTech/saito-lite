module.exports = AdminAppspaceTemplate = () => {
  return `
  <link rel="stylesheet" href="/hospital/css/admin-appspace.css">
  <h3 class="hospital-bookings-admin">Manage Hospital Appointments Available</h3>
  `;
}
