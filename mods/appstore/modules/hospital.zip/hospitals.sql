CREATE TABLE IF NOT EXISTS hospitals (
  id INTEGER ,
  name INTEGER ,
  address TEXT,
  phone INTEGER , 
  admin TEXT ,
  PRIMARY KEY(id ASC)
);

