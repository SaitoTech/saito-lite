module.exports = HospitalMakeAppointmentTemplate = () => {
  return `
  <link rel="stylesheet" href="/hospital/css/email-appspace.css">

  <h3>Available Appointments</h3>

  <div class="calendar">
    <input type="date" id="appointment-date" class="appointment-date" name="appointment-date" />
  </div>

  <div class="appointments">
  </div>

    `;
}
