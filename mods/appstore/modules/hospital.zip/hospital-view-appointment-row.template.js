module.exports = HospitalViewAppointmentRowTemplate = (dbrow) => {

  return `
  <div class="hospital" id="hospital">
      <div class="hospital-name">St. Margaret Sacred Heart</div>
      <div class="available-appointments">
        <div class="appointment-slot">7:30</div>
        <div class="notes">click here to view QR CODE for admission</div>
      </div>      
  </div>`

};
