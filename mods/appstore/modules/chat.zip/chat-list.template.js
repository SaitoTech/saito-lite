module.exports = ChatListTemplate = () => {
  return `
      <div class="chat container"></div>
      <button id="chat" class="create-button"><i class="fas fa-plus"></i></button>
  `;
}
