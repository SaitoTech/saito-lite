module.exports = ChatListTemplate = () => {
  return `
      <div class="chat-list-container"></div>
  `;
}
