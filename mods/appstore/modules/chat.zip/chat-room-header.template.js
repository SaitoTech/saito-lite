module.exports = ChatRoomHeaderTemplate = (room_name) => {
    return `
        <i id="back-button" class="icon-med fas fa-arrow-left"></i>
        <p class="chat-room-name">${room_name}</p>
    `;
}
